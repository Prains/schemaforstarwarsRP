AddCSLuaFile("cl_init.lua")
DeriveGamemode("nutscript")