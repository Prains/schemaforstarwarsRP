ITEM.name = "Малый контейнер бакты"
ITEM.category = "Medical"
ITEM.desc = "Бесцветная субстанция. Самый лучший медикамент в Галактике. Обеспечивает затягивание ран и быстрое восстановление тканей."
ITEM.model = "models/starwars/items/bacta_small.mdl"
ITEM.price = 150
ITEM.functions.Use = {
	sound = "items/medshot4.wav",
	onRun = function(item)
		item.player:SetHealth(math.min(item.player:Health() + 25, 100))
	end
}