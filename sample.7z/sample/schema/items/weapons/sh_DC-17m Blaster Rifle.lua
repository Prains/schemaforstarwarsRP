ITEM.name = "DC-17m Blaster Rifle"
ITEM.desc = "Конфигурационная боевая система коммандос Республики"
ITEM.model = "models/weapons/w_dc17m_br.mdl"
ITEM.class = "weapon_752_dc17m_br"
ITEM.weaponCategory = "primary"
ITEM.price = 4500
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	pos = Vector(-19.607843399048, 200, 2),
	ang = Angle(0, 270, 0),
	fov = 16
}
ITEM.flag = "Y"