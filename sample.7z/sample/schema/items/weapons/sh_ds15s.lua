--[[
    NutScript is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NutScript is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NutScript.  If not, see <http://www.gnu.org/licenses/>.
--]]

ITEM.name = "DS-15S"
ITEM.desc = "Тяжелый бластерный пистолет армии Республики."
ITEM.model = "models/weapons/w_dc15sa.mdl"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(-12, 189.54248046875, 3),
    ang = Angle(0, 270, 0),
    fov = 15.882352941176
}
ITEM.class = "weapon_752_dc15sa"
ITEM.weaponCategory = "sidearm"
ITEM.price = 1500
ITEM.flag = "Y"