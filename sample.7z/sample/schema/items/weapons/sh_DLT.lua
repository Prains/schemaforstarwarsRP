ITEM.name = "DLT"
ITEM.desc = "Тяжелая бластерная винтовка, использующаяся в качестве снайперской."
ITEM.model = "models/weapons/w_dlt19.mdl"
ITEM.category = "Оружие"
ITEM.class = "weapon_752_dlt19"
ITEM.weaponCategory = "primary"
ITEM.height = 1
ITEM.width = 1
ITEM.price = 5000
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}
