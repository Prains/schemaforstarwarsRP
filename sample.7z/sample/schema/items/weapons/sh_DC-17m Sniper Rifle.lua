--[[
    NutScript is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NutScript is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NutScript.  If not, see <http://www.gnu.org/licenses/>.
--]]

ITEM.name = "DC-17m Sniper Rifle"
ITEM.desc = "DC-17m со снайперской насадкой. Увеличена дальность стрельбы, оснащена снайперским прицелом. Уменьшена вместимость обоймы до 5 зарядов."
ITEM.class = "weapon_752_dc17m_sn"
ITEM.weaponCategory = "primary"
ITEM.model = "models/weapons/w_dc17m_sn.mdl"
ITEM.width = 3
ITEM.height = 1
ITEM.price = 4500
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}
ITEM.flag = "y"