ITEM.name = "Е-5"
ITEM.desc = "Автоматическая бластерная винтовка дроидов. Имеет довольно большой размер и неудобна для использования человеком."
ITEM.model = "models/weapons/w_e5.mdl"
ITEM.category = "Оружие"
ITEM.class = "weapon_752_e5"
ITEM.weaponCategory = "primary"
ITEM.height = 1
ITEM.width = 1
ITEM.price = 2400
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}
