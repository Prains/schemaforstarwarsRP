FACTION.name = "Jedi"
FACTION.desc = "Jedi"
FACTION.color = Color(0, 0, 255)
FACTION.maleModels = {"models/f3v/seeker_09.mdl"
}
FACTION.isDefault = false

FACTION_BROTHERHOOD = FACTION.index