FACTION.name = "Mercenary"
FACTION.desc = "Mercenary"
FACTION.color = Color(0, 255, 0)
FACTION.isDefault = false
FACTION.maleModels = {"models/player/scavenger/scavenger.mdl"
}
FACTION.businessAllowed = false

FACTION_CP = FACTION.index