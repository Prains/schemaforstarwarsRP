FACTION.name = "Imperial Sith"
FACTION.desc = "Imperial Sith"
FACTION.color = Color(0, 0, 255)
FACTION.maleModels = {"models/f3v/seeker_09.mdl"
}
FACTION.isDefault = false

FACTION_BROTHERHOOD = FACTION.index