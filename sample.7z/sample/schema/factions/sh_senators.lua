FACTION.name = "Senators of Tatooine"
FACTION.desc = "Senator"
FACTION.color = Color(25, 180, 30)
FACTION.Models = {"models/stalkertnb/bandit2.mdl"
}
FACTION.isDefault = false

FACTION_JOPA = FACTION.index
