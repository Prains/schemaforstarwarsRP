-- The 'nice' name of the faction.
FACTION.name = "Republic"
-- A description used in tooltips in various menus.
FACTION.desc = "Respublicans"
-- A color to distinguish factions from others, used for stuff such as
-- name color in OOC chat.
FACTION.color = Color(0, 0, 255)
-- Set the male model choices for character creation.
FACTION.maleModels = {"models/humans/group01/male_01.mdl"
}
FACTION.isDefault = false
FACTION.businessAllowed = false

-- Return what the name will be set for character creation.

-- FACTION.index is defined when the faction is registered and is just a numeric ID.
-- Here, we create a global variable for easier reference to the ID.
FACTION_RR = FACTION.index
