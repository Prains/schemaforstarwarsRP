FACTION.name = "Siths"
FACTION.desc = "Sith"
FACTION.color = Color(255, 0, 0)
FACTION.maleModels = {"models/humans/scientists/male_01.mdl", "models/humans/scientists/male_02.mdl", "models/humans/scientists/male_03.mdl"
}
FACTION.isDefault = false
FACTION.businessAllowed = false

FACTION_SITH = FACTION.index