PLUGIN.name = "Old cloth"
PLUGIN.author = "LiGyH"
PLUGIN.desc = "Плагин для упрощения айтемов одежды."