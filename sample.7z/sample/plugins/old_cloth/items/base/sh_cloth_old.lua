ITEM.name = "Cloth base"
ITEM.desc = "A cloth."
ITEM.category = "Одежда"
ITEM.model = "model"

if (CLIENT) then
	function ITEM:paintOver(item, w, h)
		if (item:getData("equip")) then
			surface.SetDrawColor(110, 255, 110, 100)
			surface.DrawRect(w - 14, h - 14, 8, 8)
		else
			surface.SetDrawColor(255, 110, 110, 100)
			surface.DrawRect(w - 14, h - 14, 8, 8)
		end
	end
end

ITEM.functions.EquipidUn = {
	name = "Снять",
	tip = "equipTip",
	icon = "icon16/cross.png",
	onRun = function(item)
	local client = item.player
		client:EmitSound("npc/combine_soldier/gear1.wav", 80)
		client:SetModel(item:getData("PreModel"))
		item:setData("equip", false)
		
		return false
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity) and item:getData("equip") == true)
	end
}

ITEM.functions.Equipid = {
	name = "Equip",
	tip = "equipTip",
	icon = "icon16/tick.png",
	onRun = function(item)
	local client = item.player
		client:EmitSound("npc/combine_soldier/gear2.wav", 80)
		item:setData("PreModel", client:GetModel())
		client:SetModel(item.model)
		item:setData("equip", true)

		return false
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity) and item:getData("equip") != true)
	end
}

ITEM:hook("drop", function(item)
	if (item:getData("equip")) then
		item:setData("equip", nil)
			item.player:EmitSound("npc/combine_soldier/gear3.wav", 80)
			client:SetModel(item:getData("PreModel"))
			item:setData("PreModel", nil)
	end
end)
ITEM.permit = "cloth"