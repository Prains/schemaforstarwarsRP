ITEM.name = "Молоко"
ITEM.desc = "Картонная упоковка молока."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_milkcarton002a.mdl"
ITEM.hunger = 0
ITEM.thirst = 25
ITEM.empty = false