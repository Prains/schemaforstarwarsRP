ITEM.name = "Мусор(Для переработки)"
ITEM.desc = "Алюминивая банка из под газировкой."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/popcan01a.mdl"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.empty = true
ITEM.permit = "food"