ITEM.name = "Мусор"
ITEM.desc = "Картонная упоковка из под молока."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_milkcarton002a.mdl"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.empty = true