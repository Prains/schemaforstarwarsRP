ITEM.name = "Элитный Гель"
ITEM.desc = "Выдается работникам CWU и лоялистам."
ITEM.category = "Еда"
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.hunger = 100
ITEM.thirst = 20
ITEM.empty = false
ITEM.permit = "food"