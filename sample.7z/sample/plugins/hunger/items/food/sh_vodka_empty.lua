ITEM.name = "Бутылка"
ITEM.desc = "Стеклянная бутылка."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/GlassBottle01a.mdl"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.empty = true