ITEM.name = "Лапша"
ITEM.desc = "Китайская лапша, более съедобна чем гель."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl"
ITEM.hunger = 40
ITEM.thirst = 0
ITEM.empty = false
ITEM.permit = "food"