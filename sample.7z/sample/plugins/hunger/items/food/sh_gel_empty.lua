ITEM.name = "Мусор(Для переработки)"
ITEM.desc = "Пустая пластиковая банка из под геля."
ITEM.category = "Еда"
ITEM.model = "models/props_lab/jar01b.mdl"
ITEM.hunger = 50
ITEM.thirst = 0
ITEM.empty = true
ITEM.permit = "food"