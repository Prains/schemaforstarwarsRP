ITEM.name = "Упаковка"
ITEM.desc = "Упаковка из под китайской лапши."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.empty = true
ITEM.permit = "food"