ITEM.name = "Бутылка"
ITEM.desc = "Стеклянная бутылка из под пива."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_glassbottle001a.mdl"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.empty = true