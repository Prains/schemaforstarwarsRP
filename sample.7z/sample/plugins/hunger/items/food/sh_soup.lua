ITEM.name = "Консервированый Суп"
ITEM.desc = "Старая консерва с супом, сойдет."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.hunger = 25
ITEM.thirst = 0
ITEM.empty = false
ITEM.permit = "food"