ITEM.name = "Консерва"
ITEM.desc = "Старая консерва из под супа."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.empty = true
ITEM.permit = "food"