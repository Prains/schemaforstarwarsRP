ITEM.name = "Газировка"
ITEM.desc = "Алюминивая банка с газировкой."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/popcan01a.mdl"
ITEM.hunger = 0
ITEM.thirst = 15
ITEM.empty = false