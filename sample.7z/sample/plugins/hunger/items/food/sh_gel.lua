ITEM.name = "Гель"
ITEM.desc = "Говорят это надо есть."
ITEM.category = "Еда"
ITEM.model = "models/props_lab/jar01b.mdl"
ITEM.hunger = 50
ITEM.thirst = 0
ITEM.empty = false
ITEM.permit = "food"