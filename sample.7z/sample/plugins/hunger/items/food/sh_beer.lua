ITEM.name = "Пиво"
ITEM.desc = "Стеклянная бутылка пива."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_glassbottle001a.mdl"
ITEM.hunger = 0
ITEM.thirst = 15
ITEM.empty = false