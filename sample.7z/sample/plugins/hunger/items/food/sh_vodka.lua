ITEM.name = "Водка"
ITEM.desc = "Стеклянная бутылка с прозрачной жидкостью."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/GlassBottle01a.mdl"
ITEM.hunger = 0
ITEM.thirst = 15
ITEM.empty = false