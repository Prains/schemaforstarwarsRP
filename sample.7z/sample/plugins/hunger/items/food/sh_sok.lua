ITEM.name = "Сок"
ITEM.desc = "3 литра сока."
ITEM.category = "Еда"
ITEM.model = "models/props_junk/garbage_plasticbottle001a.mdl"
ITEM.hunger = 0
ITEM.thirst = 70
ITEM.empty = false